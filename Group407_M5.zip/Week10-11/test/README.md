Put this `test` folder inside `Week03-05` folder, or where your `operate.py` is.

Navigate to `Week03-05` folder then run 
```
pytest test -r s
```
for verbose output, if you want succint output, run
```
pytest --tb=line test -r s
```